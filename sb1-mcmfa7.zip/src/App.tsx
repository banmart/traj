import React from 'react';
import { Brain, Activity, BarChart3, History, ArrowRight } from 'lucide-react';
import { MetricsGrid } from './components/MetricsGrid';
import { PoolTable } from './components/PoolTable';
import { ArbitrageHistory } from './components/ArbitrageHistory';
import { AutomatedArbitragePanel } from './components/AutomatedArbitragePanel';
import { useTokenMetrics } from './hooks/useTokenMetrics';
import { usePoolData } from './hooks/usePoolData';

function App() {
  const { metrics, isLoading: metricsLoading } = useTokenMetrics();
  const { pools, opportunities, history, isLoading: poolsLoading } = usePoolData();

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50">
      <nav className="border-b border-white/10 backdrop-blur-sm bg-white/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <Brain className="h-8 w-8 text-indigo-600" />
              <span className="ml-2 text-xl font-bold text-gray-900">TRAJ.AI</span>
            </div>
            <button className="px-4 py-2 rounded-lg bg-indigo-600 text-white hover:bg-indigo-700 transition">
              Connect Wallet
            </button>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <MetricsGrid metrics={metrics} isLoading={metricsLoading} />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-8">
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white/50 backdrop-blur-sm rounded-2xl p-6 border border-white/10">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-lg font-semibold text-gray-900">TRAJ Pairs</h2>
                <Activity className="h-5 w-5 text-gray-500" />
              </div>
              <PoolTable pools={pools} isLoading={poolsLoading} />
            </div>

            <div className="bg-white/50 backdrop-blur-sm rounded-2xl p-6 border border-white/10">
              <ArbitrageHistory history={history} />
            </div>
          </div>

          <div className="space-y-6">
            <div className="bg-white/50 backdrop-blur-sm rounded-2xl p-6 border border-white/10">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-lg font-semibold text-gray-900">Live Opportunities</h2>
                <BarChart3 className="h-5 w-5 text-gray-500" />
              </div>
              <div className="space-y-4">
                {opportunities?.map((opp, index) => (
                  <div key={index} className="p-4 rounded-xl bg-white/50 border border-emerald-100">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium text-gray-600">Route</span>
                      <span className="text-sm font-semibold text-emerald-600">+{opp.profitPercentage}%</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600 mb-2">
                      {opp.route.map((token, i) => (
                        <React.Fragment key={i}>
                          <span>{token}</span>
                          {i < opp.route.length - 1 && <ArrowRight className="h-4 w-4" />}
                        </React.Fragment>
                      ))}
                    </div>
                    <div className="mt-2 text-sm">
                      <span className="font-medium text-gray-900">Estimated Profit: </span>
                      <span className="text-emerald-600">${opp.estimatedProfit.toLocaleString()}</span>
                    </div>
                    <div className="mt-2 text-xs text-gray-500">
                      Confidence: {opp.confidence}% | Gas: {opp.gasEstimate} ETH
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <AutomatedArbitragePanel />
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;