import { useState, useEffect, useCallback } from 'react';
import type { ArbitrageOpportunity } from '../types/token';

interface AutomationConfig {
  minProfitMargin: number;
  maxSlippage: number;
  maxGasPrice: number;
  minLiquidity: number;
  enabled: boolean;
}

export interface ValidationCheck {
  name: string;
  status: 'success' | 'warning' | 'error';
  message: string;
}

export interface ValidationStatus {
  isValid: boolean;
  hasWarnings: boolean;
  checks: ValidationCheck[];
}

export function useAutomatedArbitrage() {
  const [config, setConfig] = useState<AutomationConfig>({
    minProfitMargin: 0.5,
    maxSlippage: 1.0,
    maxGasPrice: 50,
    minLiquidity: 10000,
    enabled: false
  });

  const [isMonitoring, setIsMonitoring] = useState(false);
  const [lastCheck, setLastCheck] = useState<Date | null>(null);
  const [activeOpportunities, setActiveOpportunities] = useState<ArbitrageOpportunity[]>([]);
  const [status, setStatus] = useState<'idle' | 'monitoring' | 'executing'>('idle');
  const [error, setError] = useState<string | null>(null);
  const [validationStatus, setValidationStatus] = useState<ValidationStatus>({
    isValid: false,
    hasWarnings: false,
    checks: []
  });

  const startMonitoring = useCallback(() => {
    if (!validationStatus.isValid) return;
    setIsMonitoring(true);
    setStatus('monitoring');
    setLastCheck(new Date());
  }, [validationStatus.isValid]);

  const stopMonitoring = useCallback(() => {
    setIsMonitoring(false);
    setStatus('idle');
  }, []);

  // Validate configuration
  const validateConfig = useCallback(() => {
    const checks: ValidationCheck[] = [];
    let isValid = true;
    let hasWarnings = false;

    // Check profit margin
    if (config.minProfitMargin <= 0) {
      checks.push({
        name: 'Minimum Profit Margin',
        status: 'error',
        message: 'Profit margin must be greater than 0%'
      });
      isValid = false;
    } else if (config.minProfitMargin < 0.3) {
      checks.push({
        name: 'Minimum Profit Margin',
        status: 'warning',
        message: 'Low profit margin may result in losses due to gas costs'
      });
      hasWarnings = true;
    } else {
      checks.push({
        name: 'Minimum Profit Margin',
        status: 'success',
        message: `Set to ${config.minProfitMargin}%`
      });
    }

    // Check slippage
    if (config.maxSlippage <= 0) {
      checks.push({
        name: 'Maximum Slippage',
        status: 'error',
        message: 'Slippage must be greater than 0%'
      });
      isValid = false;
    } else if (config.maxSlippage > 2) {
      checks.push({
        name: 'Maximum Slippage',
        status: 'warning',
        message: 'High slippage tolerance increases risk of unfavorable trades'
      });
      hasWarnings = true;
    } else {
      checks.push({
        name: 'Maximum Slippage',
        status: 'success',
        message: `Set to ${config.maxSlippage}%`
      });
    }

    // Check gas price
    if (config.maxGasPrice <= 0) {
      checks.push({
        name: 'Maximum Gas Price',
        status: 'error',
        message: 'Gas price must be greater than 0 Gwei'
      });
      isValid = false;
    } else if (config.maxGasPrice > 100) {
      checks.push({
        name: 'Maximum Gas Price',
        status: 'warning',
        message: 'High gas price limit may result in expensive transactions'
      });
      hasWarnings = true;
    } else {
      checks.push({
        name: 'Maximum Gas Price',
        status: 'success',
        message: `Set to ${config.maxGasPrice} Gwei`
      });
    }

    // Check minimum liquidity
    if (config.minLiquidity <= 0) {
      checks.push({
        name: 'Minimum Liquidity',
        status: 'error',
        message: 'Minimum liquidity must be greater than $0'
      });
      isValid = false;
    } else if (config.minLiquidity < 5000) {
      checks.push({
        name: 'Minimum Liquidity',
        status: 'warning',
        message: 'Low liquidity requirement may result in high slippage'
      });
      hasWarnings = true;
    } else {
      checks.push({
        name: 'Minimum Liquidity',
        status: 'success',
        message: `Set to $${config.minLiquidity.toLocaleString()}`
      });
    }

    setValidationStatus({ isValid, hasWarnings, checks });
  }, [config]);

  useEffect(() => {
    validateConfig();
  }, [config, validateConfig]);

  // Monitor for opportunities
  useEffect(() => {
    if (!isMonitoring) return;

    const interval = setInterval(() => {
      setLastCheck(new Date());
      // Implement opportunity scanning logic here
    }, 30000); // Check every 30 seconds

    return () => clearInterval(interval);
  }, [isMonitoring]);

  return {
    config,
    setConfig,
    status,
    lastCheck,
    activeOpportunities,
    error,
    isMonitoring,
    startMonitoring,
    stopMonitoring,
    validationStatus
  };
}