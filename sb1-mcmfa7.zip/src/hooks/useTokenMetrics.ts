import { useState, useEffect } from 'react';
import type { TokenMetrics } from '../types/token';

const mockMetrics: TokenMetrics = {
  price: 0.025678,
  marketCap: 2567800,
  totalSupply: 100000000,
  circulatingSupply: 75000000,
  burnedTokens: 5000000,
  holders: 12500,
  totalVolume24h: 750000,
  priceChange24h: 2.5,
  priceChange7d: 15.3,
  marketCapRank: 456,
  fullyDilutedValuation: 3500000,
  maxSupply: 100000000,
  totalValueLocked: 1800000,
  trades24h: 2567,
  averageTransactionValue: 292.56,
  uniqueWallets24h: 856,
  // Tax distribution metrics
  totalDistributed: 125000,
  totalBurned: 115000,
  totalDevelopment: 95000,
  distributionAPY: 42.5,
  burnRate24h: 2.8,
  developmentFunding24h: 1250
};

export function useTokenMetrics() {
  const [metrics, setMetrics] = useState<TokenMetrics | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchMetrics = async () => {
      try {
        await new Promise(resolve => setTimeout(resolve, 1000));
        setMetrics(mockMetrics);
      } catch (error) {
        console.error('Error fetching token metrics:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchMetrics();
  }, []);

  return { metrics, isLoading };
}