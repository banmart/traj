import { useState, useEffect } from 'react';
import type { PoolData, ArbitrageOpportunity, ArbitrageHistory } from '../types/token';

const mockPools: PoolData[] = [
  {
    exchange: 'PulseX',
    pairAddress: '0x1234...5678',
    token0: 'TRAJ',
    token1: 'PLS',
    liquidity: 2500000,
    volume24h: 750000,
    price: 0.025678,
    difference: 1.2,
    apr: 45.67,
    fees24h: 1234.56,
    utilization: 78.9
  },
  {
    exchange: 'PulseX',
    pairAddress: '0x8765...4321',
    token0: 'TRAJ',
    token1: 'DAI',
    liquidity: 1800000,
    volume24h: 520000,
    price: 0.025432,
    difference: -0.8,
    apr: 42.31,
    fees24h: 987.65,
    utilization: 82.3
  },
  {
    exchange: 'PulseX',
    pairAddress: '0x9876...5432',
    token0: 'TRAJ',
    token1: 'HEX',
    liquidity: 1200000,
    volume24h: 320000,
    price: 0.025789,
    difference: 1.5,
    apr: 38.92,
    fees24h: 756.43,
    utilization: 75.6
  },
  {
    exchange: 'PulseX',
    pairAddress: '0xabcd...7890',
    token0: 'TRAJ',
    token1: 'pTGC',
    liquidity: 950000,
    volume24h: 280000,
    price: 0.025901,
    difference: 2.1,
    apr: 41.75,
    fees24h: 678.90,
    utilization: 71.2
  },
  {
    exchange: 'PulseX',
    pairAddress: '0xefgh...1234',
    token0: 'TRAJ',
    token1: 'ATROPA',
    liquidity: 850000,
    volume24h: 245000,
    price: 0.025567,
    difference: -1.2,
    apr: 39.84,
    fees24h: 589.32,
    utilization: 68.9
  }
];

const mockOpportunities: ArbitrageOpportunity[] = [
  {
    buyPool: 'TRAJ/DAI',
    sellPool: 'TRAJ/PLS',
    profitPercentage: 1.2,
    estimatedProfit: 450,
    confidence: 89.5,
    gasEstimate: 0.002,
    route: ['DAI', 'TRAJ', 'PLS'],
    timestamp: Date.now()
  },
  {
    buyPool: 'TRAJ/HEX',
    sellPool: 'TRAJ/DAI',
    profitPercentage: 0.8,
    estimatedProfit: 320,
    confidence: 92.1,
    gasEstimate: 0.0015,
    route: ['HEX', 'TRAJ', 'DAI'],
    timestamp: Date.now() - 300000
  },
  {
    buyPool: 'TRAJ/pTGC',
    sellPool: 'TRAJ/ATROPA',
    profitPercentage: 1.5,
    estimatedProfit: 380,
    confidence: 87.8,
    gasEstimate: 0.0018,
    route: ['pTGC', 'TRAJ', 'ATROPA'],
    timestamp: Date.now() - 150000
  }
];

const mockHistory: ArbitrageHistory[] = [
  {
    timestamp: Date.now() - 3600000,
    profitUSD: 567.89,
    buyPool: 'TRAJ/DAI',
    sellPool: 'TRAJ/PLS',
    token0Amount: 10000,
    token1Amount: 25678,
    gasUsed: 0.0018,
    txHash: '0xabc...123'
  },
  {
    timestamp: Date.now() - 7200000,
    profitUSD: 432.12,
    buyPool: 'TRAJ/HEX',
    sellPool: 'TRAJ/DAI',
    token0Amount: 8500,
    token1Amount: 21543,
    gasUsed: 0.0015,
    txHash: '0xdef...456'
  },
  {
    timestamp: Date.now() - 5400000,
    profitUSD: 489.34,
    buyPool: 'TRAJ/pTGC',
    sellPool: 'TRAJ/ATROPA',
    token0Amount: 9200,
    token1Amount: 23456,
    gasUsed: 0.0017,
    txHash: '0xghi...789'
  }
];

export function usePoolData() {
  const [pools, setPools] = useState<PoolData[]>([]);
  const [opportunities, setOpportunities] = useState<ArbitrageOpportunity[]>([]);
  const [history, setHistory] = useState<ArbitrageHistory[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        await new Promise(resolve => setTimeout(resolve, 1000));
        setPools(mockPools);
        setOpportunities(mockOpportunities);
        setHistory(mockHistory);
      } catch (error) {
        console.error('Error fetching pool data:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, []);

  return { pools, opportunities, history, isLoading };
}