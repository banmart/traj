export interface TokenMetrics {
  price: number;
  marketCap: number;
  totalSupply: number;
  circulatingSupply: number;
  burnedTokens: number;
  holders: number;
  totalVolume24h: number;
  priceChange24h: number;
  priceChange7d: number;
  marketCapRank: number;
  fullyDilutedValuation: number;
  maxSupply: number;
  totalValueLocked: number;
  trades24h: number;
  averageTransactionValue: number;
  uniqueWallets24h: number;
  totalDistributed: number;
  totalBurned: number;
  totalDevelopment: number;
  distributionAPY: number;
  burnRate24h: number;
  developmentFunding24h: number;
}

export interface PoolData {
  exchange: string;
  pairAddress: string;
  token0: string;
  token1: string;
  liquidity: number;
  volume24h: number;
  price: number;
  difference: number;
  apr: number;
  fees24h: number;
  utilization: number;
}

export interface ArbitrageOpportunity {
  buyPool: string;
  sellPool: string;
  profitPercentage: number;
  estimatedProfit: number;
  confidence: number;
  gasEstimate: number;
  route: string[];
  timestamp: number;
}

export interface ArbitrageHistory {
  timestamp: number;
  profitUSD: number;
  buyPool: string;
  sellPool: string;
  token0Amount: number;
  token1Amount: number;
  gasUsed: number;
  txHash: string;
}