import React from 'react';
import { Play, Loader2, CheckCircle2, XCircle } from 'lucide-react';
import type { ArbitrageOpportunity } from '../types/token';
import { useArbitrage } from '../hooks/useArbitrage';

interface ArbitrageButtonProps {
  opportunity: ArbitrageOpportunity;
}

export function ArbitrageButton({ opportunity }: ArbitrageButtonProps) {
  const { executeArbitrage, isExecuting, result } = useArbitrage();

  const handleClick = async () => {
    await executeArbitrage(opportunity);
  };

  return (
    <div className="space-y-3">
      <button
        onClick={handleClick}
        disabled={isExecuting}
        className={`w-full px-4 py-2 rounded-lg font-medium transition-colors ${
          isExecuting
            ? 'bg-indigo-100 text-indigo-400 cursor-not-allowed'
            : 'bg-indigo-600 text-white hover:bg-indigo-700'
        } flex items-center justify-center gap-2`}
      >
        {isExecuting ? (
          <>
            <Loader2 className="h-4 w-4 animate-spin" />
            Executing...
          </>
        ) : (
          <>
            <Play className="h-4 w-4" />
            Execute Arbitrage
          </>
        )}
      </button>

      {result && (
        <div className={`rounded-lg p-3 text-sm ${
          result.success ? 'bg-emerald-50 text-emerald-900' : 'bg-rose-50 text-rose-900'
        }`}>
          <div className="flex items-center gap-2 mb-2">
            {result.success ? (
              <CheckCircle2 className="h-5 w-5 text-emerald-600" />
            ) : (
              <XCircle className="h-5 w-5 text-rose-600" />
            )}
            <span className="font-medium">
              {result.success ? 'Arbitrage Successful' : 'Arbitrage Failed'}
            </span>
          </div>
          
          {result.success ? (
            <div className="space-y-1">
              <p>Profit: <span className="font-medium">${result.profit?.toFixed(2)}</span></p>
              <p>Gas Used: <span className="font-medium">{result.gasUsed} ETH</span></p>
              <a
                href={`https://scan.pulsechain.com/tx/${result.txHash}`}
                target="_blank"
                rel="noopener noreferrer"
                className="text-indigo-600 hover:text-indigo-700 hover:underline"
              >
                View Transaction
              </a>
            </div>
          ) : (
            <p>{result.error}</p>
          )}
        </div>
      )}
    </div>
  );
}