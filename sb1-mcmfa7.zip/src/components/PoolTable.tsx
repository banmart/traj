import React from 'react';
import { ArrowUpRight, ArrowDownRight } from 'lucide-react';
import type { PoolData } from '../types/token';

interface PoolTableProps {
  pools: PoolData[];
  isLoading: boolean;
}

export function PoolTable({ pools, isLoading }: PoolTableProps) {
  if (isLoading) {
    return (
      <div className="animate-pulse space-y-4">
        {[...Array(3)].map((_, i) => (
          <div key={i} className="h-12 bg-gray-200 rounded"></div>
        ))}
      </div>
    );
  }

  return (
    <div className="overflow-x-auto">
      <table className="min-w-full">
        <thead>
          <tr className="border-b border-gray-200">
            <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">Pair</th>
            <th className="px-4 py-3 text-right text-sm font-medium text-gray-500">Liquidity</th>
            <th className="px-4 py-3 text-right text-sm font-medium text-gray-500">Volume (24h)</th>
            <th className="px-4 py-3 text-right text-sm font-medium text-gray-500">Price</th>
            <th className="px-4 py-3 text-right text-sm font-medium text-gray-500">APR</th>
            <th className="px-4 py-3 text-right text-sm font-medium text-gray-500">Difference</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-100">
          {pools?.map((pool, index) => (
            <tr key={index} className="hover:bg-white/30 transition">
              <td className="px-4 py-3 text-sm text-gray-900">
                {pool.token0}/{pool.token1}
              </td>
              <td className="px-4 py-3 text-sm text-right text-gray-900">
                ${pool.liquidity.toLocaleString()}
              </td>
              <td className="px-4 py-3 text-sm text-right text-gray-900">
                ${pool.volume24h.toLocaleString()}
              </td>
              <td className="px-4 py-3 text-sm text-right text-gray-900">
                ${pool.price.toFixed(6)}
              </td>
              <td className="px-4 py-3 text-sm text-right text-emerald-600">
                {pool.apr.toFixed(2)}%
              </td>
              <td className="px-4 py-3 text-sm text-right">
                <div className={`flex items-center justify-end ${
                  pool.difference >= 0 ? 'text-emerald-600' : 'text-rose-600'
                }`}>
                  {pool.difference >= 0 ? (
                    <ArrowUpRight size={16} />
                  ) : (
                    <ArrowDownRight size={16} />
                  )}
                  <span className="ml-1">{Math.abs(pool.difference)}%</span>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}