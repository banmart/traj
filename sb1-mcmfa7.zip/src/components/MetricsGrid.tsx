import React from 'react';
import { MetricsCard } from './MetricsCard';
import type { TokenMetrics } from '../types/token';

interface MetricsGridProps {
  metrics: TokenMetrics | null;
  isLoading: boolean;
}

export function MetricsGrid({ metrics, isLoading }: MetricsGridProps) {
  if (isLoading || !metrics) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[...Array(12)].map((_, i) => (
          <div key={i} className="animate-pulse bg-white/50 rounded-2xl p-6 h-24"></div>
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      <MetricsCard
        title="TRAJ Price"
        value={metrics.price}
        change={metrics.priceChange24h}
        prefix="$"
      />
      <MetricsCard
        title="Market Cap"
        value={metrics.marketCap}
        prefix="$"
      />
      <MetricsCard
        title="24h Volume"
        value={metrics.totalVolume24h}
        prefix="$"
      />
      <MetricsCard
        title="Holders"
        value={metrics.holders}
      />
      <MetricsCard
        title="Total Distributed"
        value={metrics.totalDistributed}
        suffix=" TRAJ"
        subValue={`${metrics.distributionAPY}% APY`}
      />
      <MetricsCard
        title="Total Burned"
        value={metrics.totalBurned}
        suffix=" TRAJ"
        subValue={`${metrics.burnRate24h}% 24h Rate`}
      />
      <MetricsCard
        title="Development Fund"
        value={metrics.totalDevelopment}
        suffix=" TRAJ"
        subValue={`$${metrics.developmentFunding24h} 24h`}
      />
      <MetricsCard
        title="Total Value Locked"
        value={metrics.totalValueLocked}
        prefix="$"
      />
      <MetricsCard
        title="7D Price Change"
        value={metrics.priceChange7d}
        suffix="%"
      />
      <MetricsCard
        title="24h Trades"
        value={metrics.trades24h}
      />
      <MetricsCard
        title="Unique Wallets 24h"
        value={metrics.uniqueWallets24h}
      />
      <MetricsCard
        title="Avg Transaction"
        value={metrics.averageTransactionValue}
        prefix="$"
      />
    </div>
  );
}