import React from 'react';
import { Play, Pause, Settings, AlertCircle, CheckCircle2, XCircle } from 'lucide-react';
import { useAutomatedArbitrage } from '../hooks/useAutomatedArbitrage';
import { ConfigValidation } from './ConfigValidation';

export function AutomatedArbitragePanel() {
  const {
    config,
    setConfig,
    status,
    lastCheck,
    activeOpportunities,
    error,
    isMonitoring,
    startMonitoring,
    stopMonitoring,
    validationStatus
  } = useAutomatedArbitrage();

  return (
    <div className="bg-white/50 backdrop-blur-sm rounded-2xl p-6 border border-white/10">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-lg font-semibold text-gray-900">Automated Arbitrage</h2>
        <button
          onClick={() => isMonitoring ? stopMonitoring() : startMonitoring()}
          disabled={!validationStatus.isValid}
          className={`px-4 py-2 rounded-lg font-medium transition-colors flex items-center gap-2 ${
            !validationStatus.isValid
              ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
              : isMonitoring
              ? 'bg-rose-600 text-white hover:bg-rose-700'
              : 'bg-emerald-600 text-white hover:bg-emerald-700'
          }`}
        >
          {isMonitoring ? (
            <>
              <Pause className="h-4 w-4" />
              Stop Monitoring
            </>
          ) : (
            <>
              <Play className="h-4 w-4" />
              Start Monitoring
            </>
          )}
        </button>
      </div>

      <ConfigValidation status={validationStatus} />

      <div className="space-y-4 mt-6">
        {/* Configuration */}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Min Profit Margin (%)
            </label>
            <input
              type="number"
              value={config.minProfitMargin}
              onChange={(e) => setConfig({ ...config, minProfitMargin: parseFloat(e.target.value) })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Max Slippage (%)
            </label>
            <input
              type="number"
              value={config.maxSlippage}
              onChange={(e) => setConfig({ ...config, maxSlippage: parseFloat(e.target.value) })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Max Gas Price (Gwei)
            </label>
            <input
              type="number"
              value={config.maxGasPrice}
              onChange={(e) => setConfig({ ...config, maxGasPrice: parseFloat(e.target.value) })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Min Liquidity ($)
            </label>
            <input
              type="number"
              value={config.minLiquidity}
              onChange={(e) => setConfig({ ...config, minLiquidity: parseFloat(e.target.value) })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
            />
          </div>
        </div>

        {/* Status */}
        <div className="bg-gray-50 rounded-lg p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-gray-600">Status</span>
            <span className={`text-sm font-medium ${
              status === 'monitoring' ? 'text-emerald-600' : 'text-gray-600'
            }`}>
              {status.charAt(0).toUpperCase() + status.slice(1)}
            </span>
          </div>
          {lastCheck && (
            <div className="text-xs text-gray-500">
              Last check: {lastCheck.toLocaleTimeString()}
            </div>
          )}
        </div>

        {/* Active Opportunities */}
        {activeOpportunities.length > 0 && (
          <div className="space-y-2">
            <h3 className="text-sm font-medium text-gray-700">Active Opportunities</h3>
            {activeOpportunities.map((opp, index) => (
              <div key={index} className="bg-emerald-50 rounded-lg p-3 text-sm">
                <div className="flex items-center justify-between">
                  <span className="text-emerald-700">+{opp.profitPercentage.toFixed(2)}%</span>
                  <span className="text-emerald-600">${opp.estimatedProfit.toFixed(2)}</span>
                </div>
                <div className="text-xs text-gray-600 mt-1">
                  {opp.route.join(' → ')}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Error Display */}
        {error && (
          <div className="bg-rose-50 text-rose-700 rounded-lg p-4 flex items-start gap-2">
            <AlertCircle className="h-5 w-5 flex-shrink-0 mt-0.5" />
            <div>
              <h4 className="font-medium">Error</h4>
              <p className="text-sm">{error}</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}