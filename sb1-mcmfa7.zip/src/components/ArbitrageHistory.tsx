import React from 'react';
import { Clock, ArrowRight } from 'lucide-react';
import type { ArbitrageHistory } from '../types/token';

interface ArbitrageHistoryProps {
  history: ArbitrageHistory[];
}

export function ArbitrageHistory({ history }: ArbitrageHistoryProps) {
  const formatTime = (timestamp: number) => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString();
  };

  const formatAddress = (hash: string) => {
    return `${hash.slice(0, 6)}...${hash.slice(-4)}`;
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 mb-4">
        <Clock className="h-5 w-5 text-gray-500" />
        <h3 className="text-lg font-semibold text-gray-900">Recent Arbitrages</h3>
      </div>
      <div className="space-y-3">
        {history.map((item, index) => (
          <div key={index} className="bg-white/50 rounded-lg p-4 border border-gray-100">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-gray-500">{formatTime(item.timestamp)}</span>
              <span className="text-sm font-medium text-emerald-600">
                +${item.profitUSD.toFixed(2)}
              </span>
            </div>
            <div className="flex items-center gap-2 text-sm text-gray-600 mb-2">
              <span>{item.buyPool}</span>
              <ArrowRight className="h-4 w-4" />
              <span>{item.sellPool}</span>
            </div>
            <div className="flex items-center justify-between text-xs text-gray-500">
              <span>Gas: {item.gasUsed} ETH</span>
              <a
                href={`https://scan.pulsechain.com/tx/${item.txHash}`}
                target="_blank"
                rel="noopener noreferrer"
                className="text-indigo-600 hover:text-indigo-700"
              >
                {formatAddress(item.txHash)}
              </a>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}