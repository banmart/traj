import React from 'react';
import { CheckCircle2, XCircle, AlertTriangle } from 'lucide-react';
import type { ValidationStatus } from '../hooks/useAutomatedArbitrage';

interface ConfigValidationProps {
  status: ValidationStatus;
}

export function ConfigValidation({ status }: ConfigValidationProps) {
  if (!status.checks.length) return null;

  return (
    <div className="space-y-3">
      {/* Overall Status */}
      <div className={`rounded-lg p-4 ${
        status.isValid
          ? 'bg-emerald-50'
          : status.hasWarnings
          ? 'bg-amber-50'
          : 'bg-rose-50'
      }`}>
        <div className="flex items-center gap-2">
          {status.isValid ? (
            <CheckCircle2 className="h-5 w-5 text-emerald-600" />
          ) : status.hasWarnings ? (
            <AlertTriangle className="h-5 w-5 text-amber-600" />
          ) : (
            <XCircle className="h-5 w-5 text-rose-600" />
          )}
          <span className={`font-medium ${
            status.isValid
              ? 'text-emerald-900'
              : status.hasWarnings
              ? 'text-amber-900'
              : 'text-rose-900'
          }`}>
            {status.isValid
              ? 'Configuration Valid'
              : status.hasWarnings
              ? 'Configuration Valid with Warnings'
              : 'Configuration Invalid'}
          </span>
        </div>
      </div>

      {/* Individual Checks */}
      <div className="space-y-2">
        {status.checks.map((check, index) => (
          <div
            key={index}
            className={`text-sm p-3 rounded-lg flex items-start gap-2 ${
              check.status === 'error'
                ? 'bg-rose-50 text-rose-700'
                : check.status === 'warning'
                ? 'bg-amber-50 text-amber-700'
                : 'bg-emerald-50 text-emerald-700'
            }`}
          >
            {check.status === 'error' ? (
              <XCircle className="h-4 w-4 mt-0.5" />
            ) : check.status === 'warning' ? (
              <AlertTriangle className="h-4 w-4 mt-0.5" />
            ) : (
              <CheckCircle2 className="h-4 w-4 mt-0.5" />
            )}
            <div>
              <p className="font-medium">{check.name}</p>
              <p className="text-xs mt-1 opacity-90">{check.message}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}