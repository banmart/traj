import React from 'react';
import { Sun, Moon, Monitor } from 'lucide-react';
import { useTheme } from '../hooks/useTheme';

export function ThemeSwitcher() {
  const { theme, setTheme } = useTheme();

  return (
    <div className="flex items-center gap-2 p-2 rounded-lg bg-white/10 backdrop-blur-sm">
      <button
        onClick={() => setTheme('light')}
        className={`p-2 rounded-md transition-colors ${
          theme === 'light'
            ? 'bg-indigo-100 text-indigo-600'
            : 'hover:bg-gray-100 text-gray-600'
        }`}
      >
        <Sun size={18} />
      </button>
      <button
        onClick={() => setTheme('dark')}
        className={`p-2 rounded-md transition-colors ${
          theme === 'dark'
            ? 'bg-indigo-100 text-indigo-600'
            : 'hover:bg-gray-100 text-gray-600'
        }`}
      >
        <Moon size={18} />
      </button>
      <button
        onClick={() => setTheme('system')}
        className={`p-2 rounded-md transition-colors ${
          theme === 'system'
            ? 'bg-indigo-100 text-indigo-600'
            : 'hover:bg-gray-100 text-gray-600'
        }`}
      >
        <Monitor size={18} />
      </button>
    </div>
  );
}